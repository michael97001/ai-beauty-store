<script setup>
import { ref, onMounted } from 'vue'
import { useRoute } from 'vue-router'

const props = defineProps({ mobileMenuOpen: Boolean })
const route = useRoute()
const dropdownOpen = ref(false)
const mobileDropdownOpen = ref(false)

const navItems = [
  { name: '产品', path: '/products', hasDropdown: true },
  { name: '解决方案', path: '/solutions' },
  { name: '成功案例', path: '/cases' },
  { name: '定价', path: '/pricing' },
  { name: '关于我们', path: '/about' },
  { name: '联系我们', path: '/contact' },
]

const dropdownItems = [
  { name: 'AI获客引擎', anchor: '#acquisition' },
  { name: 'AI成交助手', anchor: '#conversion' },
  { name: 'AI运营平台', anchor: '#operations' },
  { name: 'AI复购引擎', anchor: '#repurchase' },
]

onMounted(() => {
  // Close dropdown on outside click
  document.addEventListener('click', (e) => {
    if (!e.target.closest('.nav-dropdown')) dropdownOpen.value = false
  })
})
</script>

<template>
  <nav class="fixed top-0 left-0 right-0 z-[1000] bg-dark-bg/85 backdrop-blur-xl border-b border-border-subtle transition-all duration-300">
    <div class="max-w-[1200px] mx-auto px-6 h-[72px] flex items-center justify-between">
      <!-- Logo -->
      <a href="/" class="text-xl font-extrabold gradient-text">👑 AI美业</a>

      <!-- Desktop Nav -->
      <ul class="hidden lg:flex gap-7 items-center">
        <li class="nav-dropdown relative">
          <button
            @click="dropdownOpen = !dropdownOpen"
            :class="route.path === '/products' ? 'text-white font-medium' : 'text-text-muted hover:text-white font-medium'"
            class="flex items-center gap-1 py-2"
          >
            产品
            <span class="text-xs">▾</span>
          </button>
          <div v-show="dropdownOpen" class="absolute top-full left-0 mt-1 min-w-[220px] bg-[rgba(20,15,35,0.98)] border border-border-subtle rounded-xl py-2 shadow-xl backdrop-blur-xl">
            <a v-for="item in dropdownItems" :key="item.name"
               :href="item.anchor"
               class="block px-5 py-2.5 text-sm text-text-muted hover:text-white hover:bg-purple-500/10 transition-colors"
            >{{ item.name }}</a>
          </div>
        </li>
        <li v-for="item in navItems.slice(1)" :key="item.name">
          <RouterLink
            :to="item.path"
            :class="{ 'text-white font-medium': route.path === item.path }"
            class="text-text-muted hover:text-white font-medium transition-colors block py-2"
          >{{ item.name }}</RouterLink>
        </li>
      </ul>

      <!-- CTA + Hamburger -->
      <div class="flex items-center gap-3">
        <RouterLink to="/contact" class="btn-primary hidden sm:inline-flex text-sm">立即体验</RouterLink>
        <button @click="$emit('toggle-mobile')" class="lg:hidden flex flex-col gap-1.5 p-2 cursor-pointer">
          <span class="w-6 h-[2px] bg-white transition-all block"></span>
          <span class="w-6 h-[2px] bg-white transition-all block"></span>
          <span class="w-6 h-[2px] bg-white transition-all block"></span>
        </button>
      </div>
    </div>

    <!-- Mobile Menu -->
    <div v-if="mobileMenuOpen" class="lg:hidden fixed top-[72px] left-0 right-0 bottom-0 bg-dark-bg/98 backdrop-blur-xl z-[999] flex flex-col p-8 overflow-y-auto">
      <ul class="space-y-0">
        <li>
          <button @click="mobileDropdownOpen = !mobileDropdownOpen"
            class="w-full flex items-center justify-between py-4 text-lg font-medium text-white border-b border-border-subtle">
            产品 <span :class="{ 'rotate-180': mobileDropdownOpen }" class="transition-transform inline-block">▾</span>
          </button>
          <div v-show="mobileDropdownOpen" class="pl-4 pb-3 space-y-2">
            <a v-for="item in dropdownItems" :key="item.name" :href="item.anchor"
               class="block py-2.5 text-base text-text-muted hover:text-white transition-colors">{{ item.name }}</a>
          </div>
        </li>
        <li v-for="item in navItems.slice(1)" :key="item.name">
          <RouterLink :to="item.path" @click="mobileMenuOpen = false"
            class="block py-4 text-lg text-white border-b border-border-subtle hover:text-primary-light transition-colors">{{ item.name }}</RouterLink>
        </li>
      </ul>
      <div class="mt-6">
        <RouterLink to="/contact" @click="mobileMenuOpen = false" class="btn-primary w-full text-center block">立即体验</RouterLink>
      </div>
    </div>
  </nav>
</template>
