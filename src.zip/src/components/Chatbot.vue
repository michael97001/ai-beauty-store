<script setup>
import { ref } from 'vue'
import { chat } from '@/utils/ai-api.js'

const open = ref(false)
const messages = ref([
  { type: 'bot', text: '你好！我是 AI 美業顧問 👋\n\n我可以幫你了解：\n• AI 獲客方案\n• 門店診斷服務\n• 定價與訂閱\n• 預約演示\n\n請告訴我你的需求吧！' }
])
const input = ref('')
const loading = ref(false)

async function send() {
  if (!input.value.trim() || loading.value) return
  
  const userText = input.value.trim()
  messages.value.push({ type: 'user', text: userText })
  input.value = ''
  loading.value = true

  // 構建對話歷史（最近 5 條）
  const conversation = messages.value.slice(-5).map(m => ({
    role: m.type === 'user' ? 'user' : 'assistant',
    content: m.text
  }))

  try {
    const result = await chat(userText, 'chat', conversation)
    
    setTimeout(() => {
      messages.value.push({ 
        type: 'bot', 
        text: result.success ? result.data : result.fallback 
      })
      loading.value = false
    }, 500 + Math.random() * 800)
  } catch (error) {
    messages.value.push({ type: 'bot', text: '抱歉，服務暫時不可用。請重試或聯繫顧問。' })
    loading.value = false
  }
}
</script>

<template>
  <button @click="open = !open" class="chatbot-toggle">💬</button>

  <div v-if="open" class="chatbot-panel open">
    <div class="chatbot-header">
      <span class="font-bold">🤖 AI 美業顧問</span>
      <button @click="open = false" class="text-text-muted hover:text-white text-xl">×</button>
    </div>
    <div class="chatbot-messages">
      <div v-for="(msg, i) in messages" :key="i"
           :class="['chat-msg', msg.type]"
           v-html="msg.text.replace(/\n/g, '<br>')"></div>
      <div v-if="loading" class="chat-msg bot">
        <span class="inline-block w-2 h-2 bg-purple-400 rounded-full animate-bounce mr-1" style="animation-delay: 0ms;"></span>
        <span class="inline-block w-2 h-2 bg-purple-400 rounded-full animate-bounce mr-1" style="animation-delay: 150ms;"></span>
        <span class="inline-block w-2 h-2 bg-purple-400 rounded-full animate-bounce" style="animation-delay: 300ms;"></span>
      </div>
    </div>
    <div class="chatbot-input">
      <input v-model="input" @keyup.enter="send" placeholder="輸入問題..." :disabled="loading" />
      <button @click="send" :disabled="loading">{{ loading ? '...' : '發送' }}</button>
    </div>
  </div>
</template>
