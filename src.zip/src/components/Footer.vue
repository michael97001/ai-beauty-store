<script setup>
import { RouterLink } from 'vue-router'
</script>

<template>
  <footer class="bg-black/30 border-t border-border-subtle pt-16 pb-8">
    <div class="max-w-[1200px] mx-auto px-6">
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 mb-12">
        <div>
          <div class="text-xl font-extrabold gradient-text mb-3">👑 AI美业</div>
          <p class="text-text-muted text-sm leading-relaxed">帮助美发店、美容院、假发品牌实现 AI 获客、AI 成交、AI 运营、AI 复购的全链条智慧解决方案。</p>
        </div>
        <div>
          <h4 class="text-sm font-bold mb-4">产品</h4>
          <ul class="space-y-2.5">
            <li><RouterLink to="/products#acquisition" class="text-text-muted text-sm hover:text-primary-light transition-colors">AI 获客引擎</RouterLink></li>
            <li><RouterLink to="/products#conversion" class="text-text-muted text-sm hover:text-primary-light transition-colors">AI 成交助手</RouterLink></li>
            <li><RouterLink to="/products#operations" class="text-text-muted text-sm hover:text-primary-light transition-colors">AI 运营平台</RouterLink></li>
            <li><RouterLink to="/products#repurchase" class="text-text-muted text-sm hover:text-primary-light transition-colors">AI 复购引擎</RouterLink></li>
          </ul>
        </div>
        <div>
          <h4 class="text-sm font-bold mb-4">解决方案</h4>
          <ul class="space-y-2.5">
            <li><RouterLink to="/solutions#hair" class="text-text-muted text-sm hover:text-primary-light transition-colors">美发店方案</RouterLink></li>
            <li><RouterLink to="/solutions#beauty" class="text-text-muted text-sm hover:text-primary-light transition-colors">美容院方案</RouterLink></li>
            <li><RouterLink to="/solutions#wig" class="text-text-muted text-sm hover:text-primary-light transition-colors">假发品牌方案</RouterLink></li>
          </ul>
        </div>
        <div>
          <h4 class="text-sm font-bold mb-4">公司</h4>
          <ul class="space-y-2.5">
            <li><RouterLink to="/about" class="text-text-muted text-sm hover:text-primary-light transition-colors">关于我们</RouterLink></li>
            <li><RouterLink to="/cases" class="text-text-muted text-sm hover:text-primary-light transition-colors">成功案例</RouterLink></li>
            <li><RouterLink to="/pricing" class="text-text-muted text-sm hover:text-primary-light transition-colors">定价</RouterLink></li>
            <li><RouterLink to="/contact" class="text-text-muted text-sm hover:text-primary-light transition-colors">联系我们</RouterLink></li>
          </ul>
        </div>
      </div>
      <div class="border-t border-border-subtle pt-6 text-center text-text-muted text-xs">© 2026 AI美业 SaaS 平台. All rights reserved.</div>
    </div>
  </footer>
</template>
