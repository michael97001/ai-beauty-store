<script setup>
import { ref, onMounted } from 'vue'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
gsap.registerPlugin(ScrollTrigger)

const form = ref({ name: '', email: '', phone: '', industry: '', feature: '', message: '' })
const submitted = ref(false)

function submitForm() {
  if (!form.value.name || !form.value.email || !form.value.phone) {
    alert('请填写所有必填字段')
    return
  }
  submitted.value = true
  setTimeout(() => { submitted.value = false; form.value = { name: '', email: '', phone: '', industry: '', feature: '', message: '' } }, 3000)
}

onMounted(() => {
  document.querySelectorAll('.animate-on-scroll').forEach(el => {
    gsap.fromTo(el, { opacity: 0, y: 40 }, { opacity: 1, y: 0, duration: 0.8, ease: 'power2.out', scrollTrigger: { trigger: el, start: 'top 85%' } })
  })
})
</script>

<template>
  <section class="pt-32 pb-12 text-center">
    <div class="container max-w-[1200px] mx-auto px-6">
      <span class="section-label">联系我们</span>
      <h1 class="section-title">让我们开始对话</h1>
      <p class="section-subtitle mx-auto">填写表单，我们的顾问会在 24 小时内与您联系</p>
    </div>
  </section>

  <section class="py-12">
    <div class="container max-w-[900px] mx-auto px-6">
      <div class="grid md:grid-cols-2 gap-10">
        <!-- Form -->
        <div class="card animate-on-scroll">
          <h3 class="text-lg font-bold mb-6">📝 填写表单</h3>
          <form @submit.prevent="submitForm" class="space-y-4">
            <div><label class="block text-sm text-text-muted mb-1.5">姓名 *</label><input v-model="form.name" type="text" class="form-input" placeholder="您的姓名" required></div>
            <div><label class="block text-sm text-text-muted mb-1.5">Email *</label><input v-model="form.email" type="email" class="form-input" placeholder="your@email.com" required></div>
            <div><label class="block text-sm text-text-muted mb-1.5">电话 *</label><input v-model="form.phone" type="tel" class="form-input" placeholder="手机号码" required></div>
            <div><label class="block text-sm text-text-muted mb-1.5">行业类型</label><select v-model="form.industry" class="form-input"><option value="">请选择</option><option>美发店</option><option>美容院</option><option>假发品牌</option><option>其他</option></select></div>
            <div><label class="block text-sm text-text-muted mb-1.5">感兴趣的功能</label><select v-model="form.feature" class="form-input"><option value="">请选择</option><option>AI 获客引擎</option><option>AI 成交助手</option><option>AI 运营平台</option><option>AI 复购引擎</option><option>全部功能</option></select></div>
            <div><label class="block text-sm text-text-muted mb-1.5">需求描述</label><textarea v-model="form.message" class="form-input" placeholder="请描述您的需求和期望..."></textarea></div>
            <button type="submit" class="btn-primary w-full">{{ submitted ? '✅ 已提交！' : '提交表单' }}</button>
          </form>
        </div>

        <!-- Info -->
        <div>
          <div class="card animate-on-scroll mb-5">
            <h3 class="text-lg font-bold mb-4">📞 联系方式</h3>
            <ul class="space-y-3 text-text-muted text-sm"><li>📧 hello@aibeauty.saas</li><li>📱 企业微信：aa0936aa</li><li>⏰ 服务时间：周一至周五 9:00-18:00</li></ul>
          </div>
          <div class="card animate-on-scroll mb-5">
            <h3 class="text-lg font-bold mb-3">🎯 快速体验</h3>
            <p class="text-text-muted text-xs mb-3">不想填表？直接体验以下功能：</p>
            <div class="space-y-2">
              <a href="/contact#tools" class="btn-outline btn-sm block text-center py-2 text-sm">🔍 AI 门店诊断</a>
              <a href="/contact#tools" class="btn-outline btn-sm block text-center py-2 text-sm">💇 AI 发型推荐</a>
              <a href="/contact#tools" class="btn-outline btn-sm block text-center py-2 text-sm">📋 AI 获客方案</a>
            </div>
          </div>
          <div class="card animate-on-scroll">
            <h3 class="text-lg font-bold mb-3">💬 即时咨询</h3>
            <p class="text-text-muted text-sm">点击右下角聊天机器人图标，立即与 AI 顾问对话。</p>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- AI Tools Quick Access -->
  <section id="tools" class="py-20 bg-purple-500/5">
    <div class="container max-w-[700px] mx-auto px-6 text-center">
      <h2 class="section-title mb-8">🤖 立即体验 AI 工具</h2>
      <div class="grid grid-cols-3 gap-4">
        <RouterLink to="/contact#diagnosis" class="card p-6 text-center cursor-pointer hover:bg-purple-500/10 transition-colors">
          <div class="text-3xl mb-2">🔍</div>
          <div class="font-bold text-sm">AI 门店诊断</div>
          <div class="text-xs text-text-muted mt-1">6 分钟评估</div>
        </RouterLink>
        <RouterLink to="/contact#hairstyle" class="card p-6 text-center cursor-pointer hover:bg-purple-500/10 transition-colors">
          <div class="text-3xl mb-2">💇</div>
          <div class="font-bold text-sm">AI 发型推荐</div>
          <div class="text-xs text-text-muted mt-1">3 步问答</div>
        </RouterLink>
        <RouterLink to="/contact#acquisition" class="card p-6 text-center cursor-pointer hover:bg-purple-500/10 transition-colors">
          <div class="text-3xl mb-2">📋</div>
          <div class="font-bold text-sm">AI 获客方案</div>
          <div class="text-xs text-text-muted mt-1">4 题定制</div>
        </RouterLink>
      </div>
    </div>
  </section>
</template>
