<script setup>
import { onMounted, onUnmounted, ref } from 'vue'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'

gsap.registerPlugin(ScrollTrigger)
const canvasRef = ref(null)
let animFrame

onMounted(() => {
  // Hero particles canvas
  const canvas = canvasRef.value
  if (!canvas) return
  const ctx = canvas.getContext('2d')
  let w, h, particles = []

  function resize() {
    const rect = canvas.parentElement.getBoundingClientRect()
    w = canvas.width = rect.width
    h = canvas.height = rect.height
  }
  resize()

  for (let i = 0; i < 80; i++) {
    particles.push({
      x: Math.random() * w, y: Math.random() * h,
      vx: (Math.random() - 0.5) * 0.4, vy: (Math.random() - 0.5) * 0.4,
      size: Math.random() * 1.5 + 0.5, opacity: Math.random() * 0.5 + 0.1
    })
  }

  function animate() {
    ctx.clearRect(0, 0, w, h)
    particles.forEach(p => {
      p.x += p.vx; p.y += p.vy
      if (p.x < 0 || p.x > w) p.vx *= -1
      if (p.y < 0 || p.y > h) p.vy *= -1
      ctx.beginPath(); ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2)
      ctx.fillStyle = `rgba(167,139,250,${p.opacity})`; ctx.fill()
    })
    for (let i = 0; i < particles.length; i++) {
      for (let j = i + 1; j < particles.length; j++) {
        const dx = particles[i].x - particles[j].x, dy = particles[i].y - particles[j].y
        const dist = Math.sqrt(dx * dx + dy * dy)
        if (dist < 140) {
          ctx.beginPath(); ctx.moveTo(particles[i].x, particles[i].y)
          ctx.lineTo(particles[j].x, particles[j].y)
          ctx.strokeStyle = `rgba(124,58,237,${0.12 * (1 - dist / 140)})`
          ctx.lineWidth = 0.5; ctx.stroke()
        }
      }
    }
    animFrame = requestAnimationFrame(animate)
  }
  animate()

  // GSAP scroll animations
  gsap.utils.toArray('.animate-on-scroll').forEach(el => {
    gsap.fromTo(el,
      { opacity: 0, y: 40 },
      {
        opacity: 1, y: 0, duration: 0.8, ease: 'power2.out',
        scrollTrigger: { trigger: el, start: 'top 85%', toggleActions: 'play none none none' }
      }
    )
  })

  window.addEventListener('resize', resize)
})

onUnmounted(() => {
  cancelAnimationFrame(animFrame)
  window.removeEventListener('resize', () => {})
})
</script>

<template>
  <!-- Hero -->
  <section class="min-h-screen flex items-center relative overflow-hidden pt-20">
    <div class="hero-orb absolute w-[500px] h-[500px] rounded-full bg-purple-500/15 blur-[80px] -top-[10%] -left-[10%] animate-floatOrb"></div>
    <div class="hero-orb absolute w-[400px] h-[400px] rounded-full bg-pink-500/12 blur-[80px] -bottom-[10%] -right-[5%] animate-floatOrb" style="animation-delay: -3s;"></div>
    <div class="hero-orb absolute w-[300px] h-[300px] rounded-full bg-cyan-500/10 blur-[80px] top-[40%] left-[50%] animate-floatOrb" style="animation-delay: -6s;"></div>
    <div class="absolute inset-0 z-0 pointer-events-none" style="background: repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(124,58,237,0.02) 2px, rgba(124,58,237,0.02) 4px);"></div>
    <canvas ref="canvasRef" class="absolute inset-0 w-full h-full pointer-events-none z-0"></canvas>

    <div class="container max-w-[1200px] mx-auto px-6 relative z-10 py-20">
      <div class="grid lg:grid-cols-2 gap-12 items-center">
        <div>
          <span class="inline-block px-4 py-1.5 rounded-full text-xs font-semibold mb-4 border border-border-subtle bg-purple-500/10 text-purple-400">🤖 AI 美业新引擎</span>
          <h1 class="text-4xl md:text-5xl lg:text-[3.2rem] font-extrabold leading-tight mb-5">
            用 <span class="gradient-text">AI 全链条</span><br>驱动美业增长
          </h1>
          <p class="text-text-muted text-lg mb-8 max-w-xl leading-relaxed">
            帮助<strong>美发店 · 美容院 · 假发品牌</strong>实现 AI 获客、AI 成交、AI 运营、AI 复购，一站式闭环解决方案。
          </p>
          <div class="flex gap-4 mb-12 flex-wrap">
            <a href="/contact" class="btn-primary">立即免费体验</a>
            <a href="/contact" class="btn-outline">预约演示</a>
          </div>
          <div class="flex gap-10 flex-wrap">
            <div><div class="text-3xl font-black gradient-text">3000+</div><div class="text-sm text-text-muted mt-1">合作门店</div></div>
            <div><div class="text-3xl font-black gradient-text">45%</div><div class="text-sm text-text-muted mt-1">获客成本降低</div></div>
            <div><div class="text-3xl font-black gradient-text">280%</div><div class="text-sm text-text-muted mt-1">复购率提升</div></div>
          </div>
        </div>
        <div class="hidden lg:block">
          <div class="demo-window pulse-glow">
            <div class="demo-bar"><span class="demo-dot"></span><span class="demo-dot"></span><span class="demo-dot"></span></div>
            <div class="p-5 space-y-4">
              <div class="grid grid-cols-3 gap-3">
                <div class="p-3 bg-green-500/10 border border-green-500/20 rounded-xl text-center">
                  <div class="text-xl font-black text-green-400">+127</div>
                  <div class="text-[11px] text-text-muted mt-1">今日新客</div>
                </div>
                <div class="p-3 bg-purple-500/10 border border-border-subtle rounded-xl text-center">
                  <div class="text-xl font-black text-purple-400">¥86,420</div>
                  <div class="text-[11px] text-text-muted mt-1">今日营收</div>
                </div>
                <div class="p-3 bg-pink-500/10 border border-pink-500/20 rounded-xl text-center">
                  <div class="text-xl font-black text-pink-400">68%</div>
                  <div class="text-[11px] text-text-muted mt-1">复购率</div>
                </div>
              </div>
              <canvas id="ai-demo-canvas" class="w-full h-[140px] rounded-xl bg-black/20"></canvas>
              <div class="flex gap-2 justify-center">
                <span class="px-2.5 py-1 rounded-full bg-green-500/15 text-green-400 text-xs font-semibold">● AI 运行中</span>
                <span class="px-2.5 py-1 rounded-full bg-purple-500/15 text-purple-400 text-xs font-semibold">全链条闭环</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Target Clients -->
  <section class="py-16">
    <div class="container max-w-[1200px] mx-auto px-6 text-center">
      <span class="section-label">适用行业</span>
      <h2 class="section-title">为美业三大场景量身打造</h2>
      <div class="grid md:grid-cols-3 gap-6 mt-12">
        <div class="card text-center animate-on-scroll p-8">
          <div class="text-5xl mb-4">✂️</div>
          <h3 class="text-lg font-bold mb-3">美发店</h3>
          <p class="text-text-secondary text-sm leading-relaxed mb-4">AI 精准定位附近客源、智能排班减少空档、发型 AR 预览提升成交、会员自动触发复购。</p>
          <ul class="text-left text-sm text-text-muted space-y-1.5"><li>✓ LBS 附近获客</li><li>✓ AI 发型推荐</li><li>✓ 智能预约排班</li></ul>
        </div>
        <div class="card text-center animate-on-scroll p-8">
          <div class="text-5xl mb-4">💆</div>
          <h3 class="text-lg font-bold mb-3">美容院</h3>
          <p class="text-text-secondary text-sm leading-relaxed mb-4">AI 肌肤检测带入项目、疗程效果追踪建立信任、消费行为分析精准推送、自动化私域运营。</p>
          <ul class="text-left text-sm text-text-muted space-y-1.5"><li>✓ AI 肌肤检测</li><li>✓ 疗程效果量化</li><li>✓ 私域自动化运营</li></ul>
        </div>
        <div class="card text-center animate-on-scroll p-8">
          <div class="text-5xl mb-4">👩</div>
          <h3 class="text-lg font-bold mb-3">假发品牌</h3>
          <p class="text-text-secondary text-sm leading-relaxed mb-4">AI 头型分析匹配产品、虚拟试戴降低退换、用户生成内容自动分发、复购周期智能提醒。</p>
          <ul class="text-left text-sm text-text-muted space-y-1.5"><li>✓ AI 头型分析</li><li>✓ 虚拟试戴</li><li>✓ 复购周期管理</li></ul>
        </div>
      </div>
    </div>
  </section>

  <div class="glow-line"></div>

  <!-- AI Core Features -->
  <section class="py-20">
    <div class="container max-w-[1200px] mx-auto px-6">
      <div class="text-center mb-12">
        <span class="section-label">核心能力</span>
        <h2 class="section-title">AI 全链条闭环</h2>
        <p class="section-subtitle mx-auto">从获客到复购，AI 贯穿每一个经营环节，形成增长飞轮。</p>
      </div>
      <div class="grid md:grid-cols-2 gap-6">
        <div class="card animate-on-scroll border-l-[3px] border-green-500">
          <div class="flex items-center gap-4 mb-5">
            <div class="w-12 h-12 rounded-xl bg-green-500/12 flex items-center justify-center text-2xl">🎯</div>
            <div><h3 class="text-lg font-bold">AI 获客</h3><p class="text-xs text-green-500 font-semibold">ACQUIRE</p></div>
          </div>
          <p class="text-text-secondary text-sm leading-relaxed mb-4">AI 自动分析区域消费热力与人群画像，多渠道智能投放，精准锁定潜在客户，获客成本降低 45%。</p>
          <div class="flex gap-2 flex-wrap"><span class="px-3 py-1 rounded-full bg-green-500/10 text-green-500 text-xs font-semibold">LBS 附近获客</span><span class="px-3 py-1 rounded-full bg-green-500/10 text-green-500 text-xs font-semibold">AI 智能投放</span><span class="px-3 py-1 rounded-full bg-green-500/10 text-green-500 text-xs font-semibold">人群画像分析</span></div>
        </div>
        <div class="card animate-on-scroll border-l-[3px] border-purple-400">
          <div class="flex items-center gap-4 mb-5">
            <div class="w-12 h-12 rounded-xl bg-purple-500/12 flex items-center justify-center text-2xl">💰</div>
            <div><h3 class="text-lg font-bold">AI 成交</h3><p class="text-xs text-purple-400 font-semibold">CONVERT</p></div>
          </div>
          <p class="text-text-secondary text-sm leading-relaxed mb-4">AI 个性化方案推荐 + 虚拟体验（发型预览/试妆/试戴），结合智能话术辅助，成交率提升 60%。</p>
          <div class="flex gap-2 flex-wrap"><span class="px-3 py-1 rounded-full bg-purple-500/10 text-purple-400 text-xs font-semibold">AI 方案推荐</span><span class="px-3 py-1 rounded-full bg-purple-500/10 text-purple-400 text-xs font-semibold">虚拟体验</span><span class="px-3 py-1 rounded-full bg-purple-500/10 text-purple-400 text-xs font-semibold">智能话术</span></div>
        </div>
        <div class="card animate-on-scroll border-l-[3px] border-cyan-500">
          <div class="flex items-center gap-4 mb-5">
            <div class="w-12 h-12 rounded-xl bg-cyan-500/12 flex items-center justify-center text-2xl">⚙️</div>
            <div><h3 class="text-lg font-bold">AI 运营</h3><p class="text-xs text-cyan-500 font-semibold">OPERATE</p></div>
          </div>
          <p class="text-text-secondary text-sm leading-relaxed mb-4">AI 智能排班、库存预测、营收分析一键生成。员工绩效自动评估，门店营运效率提升 2 倍。</p>
          <div class="flex gap-2 flex-wrap"><span class="px-3 py-1 rounded-full bg-cyan-500/10 text-cyan-500 text-xs font-semibold">智能排班</span><span class="px-3 py-1 rounded-full bg-cyan-500/10 text-cyan-500 text-xs font-semibold">库存预测</span><span class="px-3 py-1 rounded-full bg-cyan-500/10 text-cyan-500 text-xs font-semibold">营收分析</span></div>
        </div>
        <div class="card animate-on-scroll border-l-[3px] border-pink-500">
          <div class="flex items-center gap-4 mb-5">
            <div class="w-12 h-12 rounded-xl bg-pink-500/12 flex items-center justify-center text-2xl">🔄</div>
            <div><h3 class="text-lg font-bold">AI 复购</h3><p class="text-xs text-pink-500 font-semibold">RETAIN</p></div>
          </div>
          <p class="text-text-secondary text-sm leading-relaxed mb-4">AI 分析客户消费周期，自动触发精准营销信息。个性化优惠 + 专属顾问跟进，复购率提升 280%。</p>
          <div class="flex gap-2 flex-wrap"><span class="px-3 py-1 rounded-full bg-pink-500/10 text-pink-500 text-xs font-semibold">周期预测</span><span class="px-3 py-1 rounded-full bg-pink-500/10 text-pink-500 text-xs font-semibold">自动触发营销</span><span class="px-3 py-1 rounded-full bg-pink-500/10 text-pink-500 text-xs font-semibold">专属顾问</span></div>
        </div>
      </div>
    </div>
  </section>

  <!-- Growth Flywheel -->
  <section class="py-20 bg-purple-500/5">
    <div class="container max-w-[1200px] mx-auto px-6 text-center">
      <span class="section-label">增长闭环</span>
      <h2 class="section-title">AI 驱动的增长飞轮</h2>
      <p class="section-subtitle mx-auto mb-12">获客 → 成交 → 运营 → 复购，环环相扣，自我强化。</p>
      <div class="flex items-center justify-center gap-0 flex-wrap">
        <div class="animate-on-scroll text-center p-6">
          <div class="w-20 h-20 rounded-full bg-green-500/12 border-2 border-green-500/30 flex items-center justify-center text-3xl mx-auto mb-3">🎯</div>
          <div class="font-bold">AI 获客</div><div class="text-xs text-text-muted mt-1">精准拉新</div>
        </div>
        <div class="text-purple-400 text-2xl px-2">→</div>
        <div class="animate-on-scroll text-center p-6">
          <div class="w-20 h-20 rounded-full bg-purple-500/12 border-2 border-border-subtle flex items-center justify-center text-3xl mx-auto mb-3">💰</div>
          <div class="font-bold">AI 成交</div><div class="text-xs text-text-muted mt-1">高效转化</div>
        </div>
        <div class="text-purple-400 text-2xl px-2">→</div>
        <div class="animate-on-scroll text-center p-6">
          <div class="w-20 h-20 rounded-full bg-cyan-500/12 border-2 border-cyan-500/30 flex items-center justify-center text-3xl mx-auto mb-3">⚙️</div>
          <div class="font-bold">AI 运营</div><div class="text-xs text-text-muted mt-1">降本增效</div>
        </div>
        <div class="text-purple-400 text-2xl px-2">→</div>
        <div class="animate-on-scroll text-center p-6">
          <div class="w-20 h-20 rounded-full bg-pink-500/12 border-2 border-pink-500/30 flex items-center justify-center text-3xl mx-auto mb-3">🔄</div>
          <div class="font-bold">AI 复购</div><div class="text-xs text-text-muted mt-1">持续变现</div>
        </div>
        <div class="text-purple-400 text-2xl px-2">↻</div>
      </div>
      <p class="text-text-muted text-sm mt-8">每一次复购都产生更多数据，反哺获客，形成增长飞轮</p>
    </div>
  </section>

  <!-- Results -->
  <section class="py-20">
    <div class="container max-w-[1200px] mx-auto px-6 text-center">
      <span class="section-label">实战数据</span>
      <h2 class="section-title">真实门店的 AI 转型成果</h2>
      <div class="grid grid-cols-2 md:grid-cols-4 gap-6 mt-12">
        <div class="card text-center animate-on-scroll"><div class="text-4xl font-black gradient-text">45%</div><div class="text-sm text-text-muted mt-2">获客成本降低</div></div>
        <div class="card text-center animate-on-scroll"><div class="text-4xl font-black gradient-text">60%</div><div class="text-sm text-text-muted mt-2">成交率提升</div></div>
        <div class="card text-center animate-on-scroll"><div class="text-4xl font-black gradient-text">2x</div><div class="text-sm text-text-muted mt-2">运营效率翻倍</div></div>
        <div class="card text-center animate-on-scroll"><div class="text-4xl font-black gradient-text">280%</div><div class="text-sm text-text-muted mt-2">复购率提升</div></div>
      </div>
    </div>
  </section>

  <!-- Video Showcase -->
  <section class="py-20 bg-purple-500/5">
    <div class="container max-w-[1200px] mx-auto px-6 text-center">
      <span class="section-label">视频展示</span>
      <h2 class="section-title">看 AI 如何改变美业</h2>
      <p class="section-subtitle mx-auto mb-10">3 分钟了解 AI 美业全链条解决方案</p>
    </div>
    <div class="container max-w-[800px] mx-auto px-6">
      <div class="card animate-on-scroll p-0 overflow-hidden cursor-pointer min-h-[400px] flex items-center justify-center" style="background: linear-gradient(135deg, rgba(124,58,237,0.15), rgba(236,72,153,0.1));">
        <div class="text-center">
          <div class="w-20 h-20 rounded-full gradient-text flex items-center justify-center text-3xl mx-auto mb-4 shadow-[0_0_30px_rgba(124,58,237,0.4)] pulse-glow">▶</div>
          <div class="text-base font-bold mb-1">AI 美业全链条演示</div>
          <div class="text-sm text-text-muted">观看完整介绍 →</div>
        </div>
      </div>
      <div class="grid grid-cols-3 gap-4 mt-6">
        <div class="card animate-on-scroll p-5 text-center cursor-pointer">
          <div class="h-28 bg-purple-500/8 rounded-xl mb-3 flex items-center justify-center text-2xl">🎯</div>
          <div class="text-sm font-semibold">AI 获客实战</div><div class="text-xs text-text-muted mt-1">2:30</div>
        </div>
        <div class="card animate-on-scroll p-5 text-center cursor-pointer">
          <div class="h-28 bg-pink-500/8 rounded-xl mb-3 flex items-center justify-center text-2xl">💰</div>
          <div class="text-sm font-semibold">AI 成交案例</div><div class="text-xs text-text-muted mt-1">3:15</div>
        </div>
        <div class="card animate-on-scroll p-5 text-center cursor-pointer">
          <div class="h-28 bg-cyan-500/8 rounded-xl mb-3 flex items-center justify-center text-2xl">📊</div>
          <div class="text-sm font-semibold">数据后台展示</div><div class="text-xs text-text-muted mt-1">1:45</div>
        </div>
      </div>
    </div>
  </section>

  <!-- CTA -->
  <section class="py-20 text-center relative overflow-hidden" id="demo">
    <div class="absolute inset-0" style="background: linear-gradient(135deg, rgba(124,58,237,0.15), rgba(236,72,153,0.12), rgba(6,182,212,0.08)); pointer-events:none;"></div>
    <div class="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-purple-500/10 rounded-full pointer-events-none"></div>
    <div class="container max-w-[1200px] mx-auto px-6 relative z-10">
      <h2 class="text-3xl md:text-4xl font-extrabold mb-4">准备好让 AI 驱动你的美业了吗？</h2>
      <p class="text-text-secondary text-lg max-w-[500px] mx-auto mb-9">免费体验或预约一对一演示，让我们的顾问为你展示 AI 如何改变你的业务。</p>
      <div class="flex gap-4 justify-center flex-wrap">
        <a href="/contact" class="btn-primary text-base font-bold px-9 py-3.5">立即免费体验</a>
        <a href="/contact" class="btn-outline text-base font-bold px-9 py-3.5">预约演示</a>
      </div>
    </div>
  </section>
</template>

<style scoped>
@keyframes floatOrb { 0%, 100% { transform: translate(0, 0); } 50% { transform: translate(30px, -30px); } }
.animate-floatOrb { animation: floatOrb 8s ease-in-out infinite; }
</style>
