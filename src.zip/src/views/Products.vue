<script setup>
import { onMounted } from 'vue'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
gsap.registerPlugin(ScrollTrigger)
onMounted(() => {
  document.querySelectorAll('.animate-on-scroll').forEach(el => {
    gsap.fromTo(el, { opacity: 0, y: 40 }, { opacity: 1, y: 0, duration: 0.8, ease: 'power2.out', scrollTrigger: { trigger: el, start: 'top 85%' } })
  })
})
</script>

<template>
  <section class="pt-32 pb-12 text-center">
    <div class="container max-w-[1200px] mx-auto px-6">
      <span class="section-label">产品矩阵</span>
      <h1 class="section-title">四大 AI 引擎，驱动美业增长飞轮</h1>
      <p class="section-subtitle mx-auto">从获客到复购，AI 贯穿每一个经营环节</p>
    </div>
  </section>

  <section class="py-12">
    <div class="container max-w-[1200px] mx-auto px-6">
      <div class="grid md:grid-cols-2 gap-6">
        <div id="acquisition" class="card animate-on-scroll border-l-[3px] border-green-500">
          <div class="flex items-center gap-4 mb-4">
            <div class="w-14 h-14 rounded-xl bg-green-500/12 flex items-center justify-center text-2xl">🎯</div>
            <div><h2 class="text-xl font-extrabold">AI 获客引擎</h2><p class="text-xs text-green-500 font-semibold">ACQUIRE</p></div>
          </div>
          <p class="text-text-secondary leading-relaxed mb-4">AI 自动分析区域消费热力与人群画像，多渠道智能投放，精准锁定潜在客户。</p>
          <ul class="space-y-2 text-text-muted text-sm"><li>✓ LBS 附近客源精准定位</li><li>✓ 多渠道智能投放优化</li><li>✓ 人群画像深度分析</li><li>✓ 获客成本降低 45%</li></ul>
        </div>
        <div id="conversion" class="card animate-on-scroll border-l-[3px] border-purple-400">
          <div class="flex items-center gap-4 mb-4">
            <div class="w-14 h-14 rounded-xl bg-purple-500/12 flex items-center justify-center text-2xl">💰</div>
            <div><h2 class="text-xl font-extrabold">AI 成交助手</h2><p class="text-xs text-purple-400 font-semibold">CONVERT</p></div>
          </div>
          <p class="text-text-secondary leading-relaxed mb-4">AI 个性化方案推荐 + 虚拟体验（发型预览/试妆/试戴），结合智能话术辅助。</p>
          <ul class="space-y-2 text-text-muted text-sm"><li>✓ 个性化方案推荐</li><li>✓ 虚拟体验（发型/试妆）</li><li>✓ 智能话术辅助</li><li>✓ 成交率提升 60%</li></ul>
        </div>
        <div id="operations" class="card animate-on-scroll border-l-[3px] border-cyan-500">
          <div class="flex items-center gap-4 mb-4">
            <div class="w-14 h-14 rounded-xl bg-cyan-500/12 flex items-center justify-center text-2xl">⚙️</div>
            <div><h2 class="text-xl font-extrabold">AI 运营平台</h2><p class="text-xs text-cyan-500 font-semibold">OPERATE</p></div>
          </div>
          <p class="text-text-secondary leading-relaxed mb-4">AI 智能排班、库存预测、营收分析一键生成，员工绩效自动评估。</p>
          <ul class="space-y-2 text-text-muted text-sm"><li>✓ 智能排班减少空档</li><li>✓ 库存预测防滞销</li><li>✓ 营收分析一键生成</li><li>✓ 运营效率翻倍</li></ul>
        </div>
        <div id="repurchase" class="card animate-on-scroll border-l-[3px] border-pink-500">
          <div class="flex items-center gap-4 mb-4">
            <div class="w-14 h-14 rounded-xl bg-pink-500/12 flex items-center justify-center text-2xl">🔄</div>
            <div><h2 class="text-xl font-extrabold">AI 复购引擎</h2><p class="text-xs text-pink-500 font-semibold">RETAIN</p></div>
          </div>
          <p class="text-text-secondary leading-relaxed mb-4">AI 分析客户消费周期，自动触发精准营销信息，个性化优惠 + 专属顾问跟进。</p>
          <ul class="space-y-2 text-text-muted text-sm"><li>✓ 消费周期预测</li><li>✓ 自动触发营销</li><li>✓ 个性化优惠推送</li><li>✓ 复购率提升 280%</li></ul>
        </div>
      </div>
    </div>
  </section>

  <section class="py-20 text-center">
    <div class="container max-w-[1200px] mx-auto px-6">
      <h2 class="section-title">想亲自体验这些功能吗？</h2>
      <p class="text-text-muted mb-8">免费体验或预约一对一演示</p>
      <a href="/contact" class="btn-primary">立即免费体验</a>
    </div>
  </section>
</template>
