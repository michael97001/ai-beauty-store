<script setup>
import { onMounted } from 'vue'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
gsap.registerPlugin(ScrollTrigger)
onMounted(() => {
  document.querySelectorAll('.animate-on-scroll').forEach(el => {
    gsap.fromTo(el, { opacity: 0, y: 40 }, { opacity: 1, y: 0, duration: 0.8, ease: 'power2.out', scrollTrigger: { trigger: el, start: 'top 85%' } })
  })
})
</script>

<template>
  <section class="pt-32 pb-12 text-center">
    <div class="container max-w-[1200px] mx-auto px-6">
      <span class="section-label">关于我们</span>
      <h1 class="section-title">用 AI 重新定义美业经营</h1>
      <p class="section-subtitle mx-auto max-w-[600px]">我们是一支由 AI 工程师、美业专家和数据科学家组成的团队，致力于用最前沿的 AI 技术帮助美业门店实现数字化转型。</p>
    </div>
  </section>

  <section class="py-12">
    <div class="container max-w-[800px] mx-auto px-6 space-y-6">
      <div class="card animate-on-scroll">
        <h3 class="text-lg font-bold mb-3">🎯 我们的使命</h3>
        <p class="text-text-secondary leading-relaxed">让每一家美业门店都能享受 AI 带来的效率提升和业绩增长，不分规模、不分地区。</p>
      </div>
      <div class="card animate-on-scroll">
        <h3 class="text-lg font-bold mb-3">💡 核心价值观</h3>
        <ul class="text-text-secondary space-y-2"><li>安全 — 不伤害、不泄露、不欺骗</li><li>诚实 — 真话优先，不编造数据</li><li>行动 — 解决问题，不空谈</li><li>效率 — 每句话、每个功能都有价值</li></ul>
      </div>
      <div class="card animate-on-scroll">
        <h3 class="text-lg font-bold mb-3">📊 数字说话</h3>
        <div class="grid grid-cols-3 gap-6 text-center mt-4">
          <div><div class="text-3xl font-black gradient-text">3000+</div><div class="text-xs text-text-muted mt-1">合作门店</div></div>
          <div><div class="text-3xl font-black gradient-text">50+</div><div class="text-xs text-text-muted mt-1">城市覆盖</div></div>
          <div><div class="text-3xl font-black gradient-text">99.9%</div><div class="text-xs text-text-muted mt-1">系统稳定性</div></div>
        </div>
      </div>
    </div>
  </section>
</template>
