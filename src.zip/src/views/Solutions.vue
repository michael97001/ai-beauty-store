<script setup>
import { onMounted, ref } from 'vue'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import Chart from 'chart.js/auto'

gsap.registerPlugin(ScrollTrigger)
const chartRef = ref(null)

onMounted(() => {
  document.querySelectorAll('.animate-on-scroll').forEach(el => {
    gsap.fromTo(el, { opacity: 0, y: 40 }, { opacity: 1, y: 0, duration: 0.8, ease: 'power2.out', scrollTrigger: { trigger: el, start: 'top 85%' } })
  })

  // Chart.js dashboard
  if (chartRef.value) {
    new Chart(chartRef.value, {
      type: 'line',
      data: {
        labels: ['1月','2月','3月','4月','5月','6月'],
        datasets: [
          { label: '使用 AI 前', data: [12, 15, 18, 20, 22, 25], borderColor: '#a8a3b5', backgroundColor: 'rgba(168,163,181,0.1)', tension: 0.4 },
          { label: '使用 AI 后', data: [18, 28, 42, 58, 75, 95], borderColor: '#7c3aed', backgroundColor: 'rgba(124,58,237,0.15)', tension: 0.4, fill: true },
        ]
      },
      options: {
        responsive: true,
        plugins: { legend: { labels: { color: '#a8a3b5' } } },
        scales: {
          x: { ticks: { color: '#a8a3b5' }, grid: { color: 'rgba(255,255,255,0.05)' } },
          y: { ticks: { color: '#a8a3b5' }, grid: { color: 'rgba(255,255,255,0.05)' } }
        }
      }
    })
  }
})
</script>

<template>
  <section class="pt-32 pb-12 text-center">
    <div class="container max-w-[1200px] mx-auto px-6">
      <span class="section-label">行业方案</span>
      <h1 class="section-title">为美业三大场景量身打造</h1>
      <p class="section-subtitle mx-auto">每个行业都有专属的 AI 解决方案，精准解决痛点</p>
    </div>
  </section>

  <section class="py-12">
    <div class="container max-w-[1200px] mx-auto px-6">
      <div class="grid md:grid-cols-3 gap-6">
        <div id="hair" class="card animate-on-scroll">
          <div class="text-5xl mb-4">✂️</div>
          <h3 class="text-lg font-bold mb-3">美发店</h3>
          <p class="text-text-secondary text-sm leading-relaxed mb-4">AI 精准定位附近客源、智能排班减少空档、发型 AR 预览提升成交、会员自动触发复购。</p>
          <ul class="space-y-2 text-text-muted text-sm"><li>✓ LBS 附近获客</li><li>✓ AI 发型推荐</li><li>✓ 智能预约排班</li></ul>
        </div>
        <div id="beauty" class="card animate-on-scroll">
          <div class="text-5xl mb-4">💆</div>
          <h3 class="text-lg font-bold mb-3">美容院</h3>
          <p class="text-text-secondary text-sm leading-relaxed mb-4">AI 肌肤检测带入项目、疗程效果追踪建立信任、消费行为分析精准推送、自动化私域运营。</p>
          <ul class="space-y-2 text-text-muted text-sm"><li>✓ AI 肌肤检测</li><li>✓ 疗程效果量化</li><li>✓ 私域自动化运营</li></ul>
        </div>
        <div id="wig" class="card animate-on-scroll">
          <div class="text-5xl mb-4">👩</div>
          <h3 class="text-lg font-bold mb-3">假发品牌</h3>
          <p class="text-text-secondary text-sm leading-relaxed mb-4">AI 头型分析匹配产品、虚拟试戴降低退换、用户生成内容自动分发、复购周期智能提醒。</p>
          <ul class="space-y-2 text-text-muted text-sm"><li>✓ AI 头型分析</li><li>✓ 虚拟试戴</li><li>✓ 复购周期管理</li></ul>
        </div>
      </div>
    </div>
  </section>

  <!-- Data Dashboard -->
  <section class="py-20 bg-purple-500/5">
    <div class="container max-w-[1200px] mx-auto px-6 text-center">
      <span class="section-label">数据后台</span>
      <h2 class="section-title">一站式数据驾驶舱</h2>
      <p class="section-subtitle mx-auto mb-10">所有经营数据一目了然，AI 驱动智能决策</p>
    </div>
    <div class="container max-w-[900px] mx-auto px-6">
      <div class="card animate-on-scroll border-purple-500 p-0 overflow-hidden">
        <div class="demo-bar"><span class="demo-dot"></span><span class="demo-dot"></span><span class="demo-dot"></span></div>
        <div class="p-6 grid grid-cols-4 gap-4">
          <div class="text-center p-4 bg-green-500/8 rounded-xl"><div class="text-2xl font-black text-green-400">1,247</div><div class="text-xs text-text-muted mt-2">今日到店</div></div>
          <div class="text-center p-4 bg-purple-500/8 rounded-xl"><div class="text-2xl font-black text-purple-400">¥128K</div><div class="text-xs text-text-muted mt-2">今日营收</div></div>
          <div class="text-center p-4 bg-cyan-500/8 rounded-xl"><div class="text-2xl font-black text-cyan-400">72%</div><div class="text-xs text-text-muted mt-2">复购率</div></div>
          <div class="text-center p-4 bg-pink-500/8 rounded-xl"><div class="text-2xl font-black text-pink-400">+38%</div><div class="text-xs text-text-muted mt-2">月增长</div></div>
        </div>
        <div class="p-6">
          <canvas ref="chartRef" height="200"></canvas>
        </div>
      </div>
    </div>
  </section>

  <section class="py-20 text-center">
    <div class="container max-w-[1200px] mx-auto px-6">
      <h2 class="section-title">准备好让 AI 驱动你的美业了吗？</h2>
      <p class="text-text-muted mb-8">免费体验或预约一对一演示</p>
      <a href="/contact" class="btn-primary">立即免费体验</a>
    </div>
  </section>
</template>
