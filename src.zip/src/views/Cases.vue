<script setup>
import { onMounted } from 'vue'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import Swiper from 'swiper'
import { Navigation, Pagination } from 'swiper/modules'
import 'swiper/css'
import 'swiper/css/navigation'
import 'swiper/css/pagination'

gsap.registerPlugin(ScrollTrigger)

onMounted(() => {
  document.querySelectorAll('.animate-on-scroll').forEach(el => {
    gsap.fromTo(el, { opacity: 0, y: 40 }, { opacity: 1, y: 0, duration: 0.8, ease: 'power2.out', scrollTrigger: { trigger: el, start: 'top 85%' } })
  })

  new Swiper('.testimonial-swiper', {
    modules: [Navigation, Pagination],
    slidesPerView: 1,
    spaceBetween: 20,
    navigation: true,
    pagination: { clickable: true },
    loop: true,
  })
})

const cases = [
  { name: '台北·时尚发廊', revenue: '月营收从 25 万 → 58 万', metrics: ['获客成本 -52%', '复购率 +340%'], quote: '「AI 获客引擎帮我们精准锁定附近高消费力客群，一个月营收翻倍。」' },
  { name: '上海·美妍美容', revenue: '月营收从 40 万 → 95 万', metrics: ['成交率 +68%', '空档率 -40%'], quote: '「AI 成交助手搭配虚拟试妆，顾客满意度和成交率都大幅提升。」' },
  { name: '东京·LuxeWigs', revenue: '月营收从 60 万 → 130 万', metrics: ['退换率 -60%', '复购 +250%'], quote: '「AI 头型分析和虚拟试戴让我们退换率大幅降低，客户体验超好。」' },
  { name: '高雄·髮间美学', revenue: '月营收从 18 万 → 42 万', metrics: ['新客 +180%', '员工效率 +2x'], quote: '「智能排班让我们的空档率从 35% 降到 8%，省下的就是赚到的。」' },
  { name: '成都·颜值管理', revenue: '月营收从 35 万 → 78 万', metrics: ['私域用户 +5000', '自动化触达'], quote: '「AI 运营平台把我们的私域运营效率提升了 3 倍，省了两个人力。」' },
  { name: '深圳·顶尖发艺', revenue: '月营收从 50 万 → 120 万', metrics: ['ROI 450%', '会员活跃 +200%'], quote: '「AI 复购引擎自动追踪每位会员的消费周期，复购率直接翻倍。」' },
]
</script>

<template>
  <section class="pt-32 pb-12 text-center">
    <div class="container max-w-[1200px] mx-auto px-6">
      <span class="section-label">成功案例</span>
      <h1 class="section-title">真实门店的 AI 转型成果</h1>
      <p class="section-subtitle mx-auto">超过 3000 家美业门店使用 AI Beauty 实现业绩增长</p>
    </div>
  </section>

  <section class="py-12">
    <div class="container max-w-[1200px] mx-auto px-6">
      <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        <div v-for="c in cases" :key="c.name" class="card case-card animate-on-scroll overflow-hidden">
          <div class="p-6">
            <h3 class="font-bold">{{ c.name }}</h3>
            <p class="text-text-muted text-sm mt-1">{{ c.revenue }}</p>
            <div class="flex gap-2 flex-wrap mt-3">
              <span v-for="m in c.metrics" :key="m" class="px-2.5 py-1 rounded-full bg-purple-500/10 text-purple-400 text-xs font-semibold">{{ m }}</span>
            </div>
            <div class="mt-4 p-4 bg-black/20 rounded-xl italic text-sm text-text-muted">「{{ c.quote }}」</div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Testimonial Swiper -->
  <section class="py-20 bg-purple-500/5">
    <div class="container max-w-[700px] mx-auto px-6 text-center">
      <h2 class="section-title mb-10">客户评价</h2>
      <div class="swiper testimonial-swiper">
        <div class="swiper-wrapper">
          <div v-for="i in 6" :key="i" class="swiper-slide">
            <div class="card p-8 text-center">
              <p class="text-text-secondary italic mb-4">"使用 AI Beauty 后，我们的获客成本降低了 40%，复购率提升了 200%。这是真正的数字化转型。"</p>
              <div class="font-bold">— 某美发连锁店创始人</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="py-20 text-center">
    <div class="container max-w-[1200px] mx-auto px-6">
      <h2 class="section-title">也想成为下一个成功案例？</h2>
      <p class="text-text-muted mb-8">立即免费体验或预约演示</p>
      <a href="/contact" class="btn-primary">开始免费体验</a>
    </div>
  </section>
</template>
