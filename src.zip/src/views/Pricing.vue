<script setup>
import { ref } from 'vue'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
gsap.registerPlugin(ScrollTrigger)

const billing = ref('monthly')
const faqOpen = ref(null)

const toggleFaq = (i) => { faqOpen.value = faqOpen.value === i ? null : i }

onMounted(() => {
  document.querySelectorAll('.animate-on-scroll').forEach(el => {
    gsap.fromTo(el, { opacity: 0, y: 40 }, { opacity: 1, y: 0, duration: 0.8, ease: 'power2.out', scrollTrigger: { trigger: el, start: 'top 85%' } })
  })
})
</script>

<template>
  <section class="pt-32 pb-12 text-center">
    <div class="container max-w-[1200px] mx-auto px-6">
      <span class="section-label">定价方案</span>
      <h1 class="section-title">简单透明的定价</h1>
      <p class="section-subtitle mx-auto">所有方案均含 AI 全链条功能，无隐藏费用</p>
    </div>
  </section>

  <section class="py-12">
    <div class="container max-w-[1000px] mx-auto px-6">
      <div class="grid md:grid-cols-3 gap-6">
        <!-- Free -->
        <div class="card pricing-card animate-on-scroll">
          <h3 class="text-lg font-bold mb-2">免费版</h3>
          <div class="text-4xl font-black gradient-text mb-1">¥0</div>
          <div class="text-text-muted text-sm mb-6">永久免费</div>
          <ul class="space-y-3 mb-6 text-left"><li class="text-text-muted text-sm">✓ 基础 AI 获客功能</li><li class="text-text-muted text-sm">✓ 每月 50 次 AI 诊断</li><li class="text-text-muted text-sm">✓ 基础数据报表</li><li class="text-text-muted text-sm">✓ 社群支持</li></ul>
          <a href="/contact" class="btn-outline w-full text-center block">免费开始</a>
        </div>
        <!-- Pro -->
        <div class="card pricing-card featured animate-on-scroll border-purple-500 shadow-[0_0_40px_rgba(124,58,237,0.2)] relative">
          <div class="absolute -top-3 right-4 bg-gradient-to-r from-purple-500 to-pink-500 text-white text-xs font-bold px-4 py-1 rounded-full">推荐</div>
          <h3 class="text-lg font-bold mb-2">专业版</h3>
          <div class="text-4xl font-black gradient-text mb-1">¥2,999</div>
          <div class="text-text-muted text-sm mb-6">/月</div>
          <ul class="space-y-3 mb-6 text-left"><li class="text-text-muted text-sm">✓ 完整 AI 全链条功能</li><li class="text-text-muted text-sm">✓ 无限 AI 诊断次数</li><li class="text-text-muted text-sm">✓ 进阶数据分析</li><li class="text-text-muted text-sm">✓ 优先客服支持</li><li class="text-text-muted text-sm">✓ 自定义品牌外壳</li></ul>
          <a href="/contact" class="btn-primary w-full text-center block">立即订阅</a>
        </div>
        <!-- Enterprise -->
        <div class="card pricing-card animate-on-scroll">
          <h3 class="text-lg font-bold mb-2">企业版</h3>
          <div class="text-2xl font-black gradient-text mb-1">定制报价</div>
          <div class="text-text-muted text-sm mb-6">联系我们</div>
          <ul class="space-y-3 mb-6 text-left"><li class="text-text-muted text-sm">✓ 专业版全部功能</li><li class="text-text-muted text-sm">✓ 专属 API 接入</li><li class="text-text-muted text-sm">✓ 私有化部署选项</li><li class="text-text-muted text-sm">✓ 1 对 1 顾问服务</li><li class="text-text-muted text-sm">✓ SLA 保障</li></ul>
          <a href="/contact" class="btn-outline w-full text-center block">联系销售</a>
        </div>
      </div>
    </div>
  </section>

  <!-- FAQ -->
  <section class="py-20 bg-purple-500/5">
    <div class="container max-w-[700px] mx-auto px-6">
      <h2 class="section-title text-center mb-8">常见问题</h2>
      <div class="faq-item" v-for="(faq, i) in [
        { q: '免费体验结束后会自动扣款吗？', a: '不会。试用结束后你没有主动订阅，账号会自动转为只读模式，不会产生任何费用。' },
        { q: '可以随时升级或降级方案吗？', a: '可以。你可以在任何时候变更方案，费用会按比例计算。' },
        { q: '数据安全有保障吗？', a: '我们采用 AES-256 加密、SOC 2 Type II 认证，所有资料储存在台湾本地数据中心。' },
        { q: '适用的行业有哪些？', a: '我们专注于美发店、美容院、假发品牌三大美业场景，每个场景都有专属的 AI 解决方案。' },
      ]" :key="i">
        <button @click="toggleFaq(i)" :class="{ 'active': faqOpen === i }" class="faq-question">{{ faq.q }}<span class="faq-icon">+</span></button>
        <div :class="{ 'open': faqOpen === i }" class="faq-answer">{{ faq.a }}</div>
      </div>
    </div>
  </section>

  <section class="py-20 text-center">
    <div class="container max-w-[1200px] mx-auto px-6">
      <h2 class="section-title">还有疑问？</h2>
      <p class="text-text-muted mb-8">我们的顾问随时为你解答</p>
      <a href="/contact" class="btn-primary">联系我们</a>
    </div>
  </section>
</template>
