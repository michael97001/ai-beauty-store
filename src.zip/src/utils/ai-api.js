// AI API 調用工具
const API_BASE = 'http://localhost:3001/api'

/**
 * 通用對話接口
 * @param {string} message - 用戶消息
 * @param {string} type - 對話類型：chat | diagnosis | hairstyle | acquisition
 * @param {Array} conversation - 歷史對話
 * @returns {Promise<Object>}
 */
export async function chat(message, type = 'chat', conversation = []) {
  try {
    const response = await fetch(`${API_BASE}/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message, conversation, type })
    })
    
    if (!response.ok) throw new Error('網絡回應異常')
    
    const data = await response.json()
    return { success: true, data: data.reply }
  } catch (error) {
    console.error('AI 對話錯誤:', error)
    return { 
      success: false, 
      error: 'AI 服務暫時不可用，請稍後重試',
      fallback: generateFallbackReply(message, type)
    }
  }
}

/**
 * AI 診斷接口
 * @param {Object} params - 診斷參數
 * @returns {Promise<Object>}
 */
export async function diagnose(params) {
  try {
    const response = await fetch(`${API_BASE}/diagnosis`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params)
    })
    
    if (!response.ok) throw new Error('網絡回應異常')
    
    const data = await response.json()
    return { success: true, data: data.result }
  } catch (error) {
    console.error('診斷錯誤:', error)
    return { success: false, error: '診斷服務暫時不可用' }
  }
}

/**
 * AI 髮型推薦接口
 * @param {Object} params - 推薦參數
 * @returns {Promise<Object>}
 */
export async function recommendHairstyle(params) {
  try {
    const response = await fetch(`${API_BASE}/hairstyle`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params)
    })
    
    if (!response.ok) throw new Error('網絡回應異常')
    
    const data = await response.json()
    return { success: true, data: data.results }
  } catch (error) {
    console.error('髮型推薦錯誤:', error)
    return { success: false, error: '推薦服務暫時不可用' }
  }
}

/**
 * AI 獲客方案接口
 * @param {Object} params - 方案參數
 * @returns {Promise<Object>}
 */
export async function generateAcquisitionPlan(params) {
  try {
    const response = await fetch(`${API_BASE}/acquisition`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params)
    })
    
    if (!response.ok) throw new Error('網絡回應異常')
    
    const data = await response.json()
    return { success: true, data: data.plan }
  } catch (error) {
    console.error('獲客方案錯誤:', error)
    return { success: false, error: '方案生成服務暫時不可用' }
  }
}

/**
 * 備用回覆（當 AI 服務不可用時）
 */
function generateFallbackReply(message, type) {
  const fallbacks = {
    diagnosis: `感謝您的諮詢！🤖

AI 診斷功能正在載入中，以下是基於您輸入的初步建議：

📊 **初步評估：**
• 建議先進行完整的 6 分鐘 AI 診斷
• 我們的顧問會在 24 小時內為您提供專業分析
• 您可以先體驗我們的免費版功能

💡 **立即行動：**
1. 填寫聯繫表單預約診斷
2. 或點擊右下角聊天機器人諮詢

📞 聯繫我們獲取完整報告`,

    hairstyle: `造型師正在為您工作中！💇‍♀️

以下是基於您資訊的初步推薦：

✨ **推薦髮型：**
1. **經典短髮** - 適合多數臉型，清爽利落
2. **微捲中長髮** - 溫柔知性，百搭風格
3. **層次長髮** - 修飾臉型，氣質優雅
4. **時尚短鮑伯** - 現代感強，個性十足

💡 建議預約到店進行 AI 虛擬試戴體驗！`,

    acquisition: `獲客方案生成中！📈

以下是初步策略建議：

🎯 **渠道策略：**
• LBS 附近精準投放（抖音/小紅書/微信）
• KOL/KOC 合作推廣
• 會員轉介紹獎勵計劃

💡 **內容策略：**
• 前後對比案例分享
• 專家知識科普內容
• 用戶見證與評價

📊 **預期效果：**
• 月均新客增長 30-50%
• 獲客成本降低 20-30%

💬 聯繫我們獲取完整定制方案`,

    chat: `您好！我是 AI 美業顧問 🤖

我正在學習中，目前可以提供以下幫助：

🔹 **產品介紹：** AI 獲客、成交、運營、復購四大引擎
🔹 **行業方案：** 髮廊、美容院、假髮品牌專屬方案
🔹 **定價諮詢：** 免費版、專業版、企業版
🔹 **預約演示：** 一對一產品體驗

💡 您也可以直接瀏覽我們的產品頁面或填寫聯繫表單獲取專業顧問服務！`
  }
  
  return fallbacks[type] || fallbacks.chat
}
